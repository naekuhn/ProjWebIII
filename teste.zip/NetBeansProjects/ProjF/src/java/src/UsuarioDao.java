/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package src;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Peterson Kuhn
 */
public class UsuarioDao{
    
    public static Connection getConnection(){
    
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/crudjspjava","root","root");
        }catch (ClassNotFoundException | SQLException e){
            System.out.println(e);
        }
       return con;
    }
    
    public static List<Usuario> getAllUsuarios(){
        List<Usuario> List = new ArrayList<Usuario>();
        
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.preparedStatement("SELECT * FROM usuario");
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()) {
                Usuario usuario new Usuario();
                usuario.setId(rs.getInt("id"));
                usuario.setNome(rs.getString("nome"));
                usuario.setPassword(rs.getString("password"));
                usuario.setPais(rs.getString("pais"));
                list.add(usuario);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
}
